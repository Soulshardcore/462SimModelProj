﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurnManager : MonoBehaviour
{
    static Dictionary<string, List<TacticsMove>> units = new Dictionary<string, List<TacticsMove>>(); //dictionary containing all the units in the game
    static Queue<string> turnKey = new Queue<string>(); //queue of the different units for a turn
    static Queue<TacticsMove> turnTeam = new Queue<TacticsMove>(); //queue for the different teams to determine whose turn it is

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //starts the turn manager
        if (turnTeam.Count == 0)
        {
            initTeamTurnQueue();
        }
    }

    //Initilizes the turn queue
    static void initTeamTurnQueue()
    {
        List<TacticsMove> teamList = units[turnKey.Peek()]; //makes the list of Tactics moves and makes them the list of teams

        //for all the teams
        foreach(TacticsMove unit in teamList)
        {
            turnTeam.Enqueue(unit); //add to the queue
        }

        StartTurn(); //begin the turn for the first team
    }


    //starts the turn for a team
    public static void StartTurn()
    {
        //as long as there are teams left 
        if(turnTeam.Count > 0)
        {
            turnTeam.Peek().BeginTurn(); //begin their turn
        }
    }

    //ends the turn for the current team
    public static void EndTurn()
    {
        TacticsMove unit = turnTeam.Dequeue(); //remove current team from queue to make next team the head of the queue
        unit.EndTurn(); //call the end turn

        //as long as there is another team
        if(turnTeam.Count > 0)
        {
            StartTurn(); //begin its turn
        }
        else
        {
            string team = turnKey.Dequeue(); //if no units for that team, remove the team from the list
            turnKey.Enqueue(team); //add the team back to the list so they can move on their next turn
            initTeamTurnQueue();
        }
    }

    //add a unit to the list. the units will add themselves when they are made
    public static void AddUnit(TacticsMove unit)
    {
        List<TacticsMove> list; //make a list 

        //if there is no units with the current tag
        if(!units.ContainsKey(unit.tag))
        {
            list = new List<TacticsMove>(); //add the tag to the list
            units[unit.tag] = list; //adds the tag


            if(!turnKey.Contains(unit.tag))
            {
                turnKey.Enqueue(unit.tag); //add the tag to the queue
            }
        }
        //otherwise, just add to the list the units of that tag
        else
        {
            list = units[unit.tag];
        }

        list.Add(unit); //add the unit created to the list
    }


    /*
     Make remove unit function and remove turnkey function
     make sure turn ends after unit does some sort of action instead of after move
     
     */
}
