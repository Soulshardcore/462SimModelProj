﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//this is without diagonal movement
//This is for the tiles and when they will be moved.

public class TileScript : MonoBehaviour
{
    //need the variables
    public bool walkable = true; //if you can walk through the tile. For tiles where movement is impossible  
    public bool current = false; //will be true if a player or enemy is standing on it
    public bool target = false; //where we are moving to
    public bool selectable = false; //will be true if the player is allowed to move to that tile

    public List<TileScript> adjacencyList = new List<TileScript>(); //a list of the tiles that surround a given tile

    //for BFS (Breadth First Search)
    public bool visited = false; //tile is processed
    public TileScript parent = null; //the previous tile. For pathfinding
    public int distance = 0; //how far each tile is from start tile. 
    //Players can NPCS can only move so far. If we hit that distance, we will stop to make sure they cant move out of range.

    //For A*
    public float f = 0; // G + H
    public float g = 0; //cost of parent to current tile
    public float h = 0; //heuristic cost, from processed tile to current destination


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (current)
        {
            //will change the color of the tile if the player or the enemy is standing on it
            GetComponent<Renderer>().material.color = Color.magenta;
            //Debug.Log("We have liftoff");
            //Debug.Log("There is a player object above: " + gameObject.name);
        }
        else if (target)
        {
            //if the tile is the one selected by the player, it will turn green 
            GetComponent<Renderer>().material.color = Color.green;
            //Debug.Log("YOU WERE THE CHOSEN ONE");
        }
        else if (selectable)
        {
            //if the tile can be selected make it turn blue
            GetComponent<Renderer>().material.color = Color.blue;
            //Debug.Log("A tile is selectable");
        }
        //
        //else if (!current && !target && !selectable)
        //{

        //    //if not one of the other options, go back to the original color
        //    GetComponent<Renderer>().material.color = Color.white;
        //}

    }

    //Every turn we need to bring all the variables back to their original values. 
    //This will set all the values to their default values
    public void Reset()
    {
        //need the variables
        walkable = true; //if you can walk through the tile. For tiles where movement is impossible  
        current = false; //will be true if a player or enemy is standing on it
        target = false; //where we are moving to
        selectable = false; //will be true if the player is allowed to move to that tile

    
        //for BFS (Breadth First Search)
        visited = false; //tile is processed
        parent = null; //the previous tile. For pathfinding
        distance = 0; //how far each tile is from start tile. 

        f = 0;
        g = 0;
        h = 0;

        adjacencyList.Clear(); //clear the list of neighbors
        
    }

    //fild adjecent tiles
    public void FindNeighbors(float jumpHeight, TileScript target)
    {
        Reset(); //make sure everything is set back to its original state
        //call check tile for all the tiles around it
        //Debug.Log("Calling Find Neighbors for " + gameObject.name);
        CheckTile(Vector3.forward, jumpHeight, target); // x axis
        CheckTile(-Vector3.forward, jumpHeight, target); // negative x axis
        CheckTile(Vector3.right, jumpHeight, target); // z axis
        CheckTile(-Vector3.right, jumpHeight, target); // negative z axis
        //the jump height is how many tiles a player cna jump up or down

    }

    //to check the tile nearby 
    public void CheckTile(Vector3 direction, float jumpHeight, TileScript target)
    {
        //jump height of 2 (default) means that if there is a distance of <=2 it is walkable.
        //Determines how high or low they will be able to jump

        //the half extents for the colliders
        Vector3 halfExtents = new Vector3(0.25f, (1 + jumpHeight) /2.0f, 0.25f);
        //need to compute y to determine if there is a tile they can jump to
        //each tile is 1 high and we have a jump height. We also need to fall down 2. This will give the range of jumping

        //will use physics to get an array of colliders, to determine if there is a box next do the 
        Collider[] colliders = Physics.OverlapBox(transform.position + direction, halfExtents); 

        //go through the list of colliders
        foreach(Collider item in colliders)
        {
            TileScript tile = item.GetComponent<TileScript>(); //checks if there is a tile where we wanrt to go
            //as long as there is a tile there and it is walkable
            if(tile != null && tile.walkable)
            {
                //need to make sure there is nothing ontop of the tile we are attempting to get to
                RaycastHit hit;
                //checks to make sure there is nothing on the tile its trying, if there is nothing there, add
                //Debug.Log(Physics.Raycast(tile.transform.position, Vector3.up, out hit, 1) + ": returns true if there is no object above tile");
                if(!Physics.Raycast(tile.transform.position, Vector3.up, out hit, 1) || (tile == target))
                {
                    //Debug.Log("Detected and added tile to list in specified direction; " + direction.ToString());
                    adjacencyList.Add(tile);
                }
                else
                {
                    //Debug.Log("Failure to detect tile in specified direction;" + direction.ToString());
                }
                //if we run into something, or cant go there, we will not add to the list 
            }
        }

    }


}
