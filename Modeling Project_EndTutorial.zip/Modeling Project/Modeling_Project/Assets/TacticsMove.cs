﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Tactis Move will be used for all of the movement of both the player and enemy objects. 
//Contains all the movement algorithms as it is shared by players and NPCs
public class TacticsMove : MonoBehaviour
{
    public bool turn = false;

    public int move = 5; //how far the player can move. Defauls to 5
    public float jumpHeight = 2; //how far the player can jump, defaults to 2
    public float moveSpeed = 2; //how fast the unit will walk across the tiles

    public bool moving = false; //only look when its not moving

    bool fallingDown = false;
    bool jumpingUp = false;
    bool movingEdge = false;
    Vector3 jumpTarget;
    public float jumpVelocity = 4.5f;

    Vector3 velocity = new Vector3(); //the velocity
    Vector3 heading = new Vector3(); //the direction the player is heading in
    List<TileScript> selectableTiles = new List<TileScript>(); //a list of the tiles the player can access, so we can change their color as needed
    GameObject[] tiles; //list of tiles as game objects

    Stack<TileScript> path = new Stack<TileScript>(); //allows us to backtrack to the starting tile
    TileScript currentTile; //the tile the player is on

    float halfHeight = 0; //how tall half the tile is

    public TileScript actualTargetTile;

    //init function
    protected void Init()
    {
        tiles = GameObject.FindGameObjectsWithTag("Tile"); //gets all the tiles on the board
        halfHeight = GetComponent<Collider>().bounds.extents.y; //to calculate where to put the unit on the tile
        TurnManager.AddUnit(this);
    }

    //allows us to get current tile
    public void GetCurrentTile()
    {
        currentTile = GetTargetTile(gameObject); //gets the tile the player is currently sitting on
        currentTile.current = true; //assigns this tile the needed color of the current tile
    }

    //to get the target tile that we want to go to
    public TileScript GetTargetTile(GameObject target)
    {
        //needs to find the tile we are looking for

        RaycastHit hit;
        TileScript tile = null; //the tile we are looking for

        //checks to make sure there is a tile there
        //Debug.Log(Physics.Raycast(target.transform.position, -Vector3.up, out hit, 1) + " is response for should be player tile");
        if (Physics.Raycast(target.transform.position, -Vector3.up, out hit, 1))
        {
            tile = hit.collider.GetComponent<TileScript>(); //gets the tile that was there if there is one
        }

        return tile; //returns the tile we desire
    }

    //to get the tiles that are adjecent
    public void ComputedAdjencyLists(float jumpHeight, TileScript target)
    {
        //goes through all the tiles
        foreach(GameObject tile in tiles)
        {
            TileScript t = tile.GetComponent<TileScript>(); //gets the current tile in the list
            t.FindNeighbors(jumpHeight, target); //finds the neighbor tiles
        }
    }
    
    //will be used to do the BFS and find the tiles it can do
    public void FindSelectableTiles()
    {
        ComputedAdjencyLists(jumpHeight, null); //get the adject tiles
        GetCurrentTile(); //get the current tile

        Queue<TileScript> process = new Queue<TileScript>(); //makes a queue of the needed tiles

        process.Enqueue(currentTile); //will put the current tile in the queue
        currentTile.visited = true; //we dont want to come back to this tile after we visit it 
        //currentTile.parent = ?? //leave as null beacuse we dont want to include current tile in the path

        //as long as the queue is not empty
        while(process.Count > 0)
        {
            
            //prcess the tile at the head of the queue
            TileScript t = process.Dequeue(); //removes the first tile from the queue

            selectableTiles.Add(t); //adds the tile to the selectable list 
            t.selectable = true; //makes its color change to reflect you can pick it
            //Debug.Log("starting process");
            //need to check the distance if bigger than the move, we cant do
            if (t.distance < move)
            {
                //Debug.Log("It made it into t.distance < move");
                //need to add all its neighbors to the queue
                foreach (TileScript tile in t.adjacencyList)
                {
                    //Debug.Log("It made it into foreach");
                    //need to make sure we dont process the same tiles twice
                    if (!tile.visited)
                    {
                        tile.parent = t; //if the tile is visited make the current tile its parent
                                         //will set that for those adjectent to the tile
                        tile.visited = true; //we visited it
                        tile.distance = 1 + t.distance; //increases the distance
                        process.Enqueue(tile); //add it to the queue
                        //Debug.Log("Tile added to queue: " + tile.gameObject.ToString());
                    }
                    else
                    {
                        //Debug.Log("Tried to access a visited tile");
                    }
                }
            }
        }
    }

    //To allow the player to move to the tile they selected
    public void MoveToTile(TileScript tile)
    {
        path.Clear(); //clear any previous path
        tile.target = true; //becomes the target tile
        moving = true; //start moving

        //make it the next tile
        TileScript nextTile = tile;
        //while we are not at the tile with no parent
        while(nextTile != null)
        {
            path.Push(nextTile); //add to the path stack
            nextTile = nextTile.parent; //make the next tile the parent to move back in the path
        }
    }

    //moves the player to the tile
    public void Move()
    {
        //as long as there is a path
        if(path.Count > 0)
        {
            TileScript t = path.Peek(); //peek at the next tile in path
            Vector3 target = t.transform.position; //transform the current position
              
            //Move the player onto the square where they should be, and make sure they aren't halfway in the square or what have you
            target.y += halfHeight + t.GetComponent<Collider>().bounds.extents.y;

            //if the distance is bigger than .05
            if(Vector3.Distance(transform.position, target) >= 0.05f)
            {
                bool jump = transform.position.y != target.y; //if the player has to jump
               
                //if they have to jump
                if (jump)
                {
                    Jumping(target); 
                }
                //if they do not have to jump
                else
                {
                    CalculateHeading(target);
                    SetHorizontalVelocity();
                }

                transform.forward = heading;
                transform.position += velocity * Time.deltaTime; //moves the position
            }
            else
            {
                //tile reached
                transform.position = target;
                path.Pop(); //remove form stack
            }
        }
        else
        {
            RemoveSelectableTiles(); //remove the tiles that were selectable 
            moving = false; //end the moving

            TurnManager.EndTurn(); //end the turn
        }
    }

    //to remove the tiles that were selectable
    protected void RemoveSelectableTiles()
    {
        //as long as there is a current tile
        if(currentTile != null)
        {
            currentTile.current = false; //make it not the current tile
            currentTile = null; //make no current tile
        }

        //for all of the perviously selectable tiles
        foreach(TileScript Tile in selectableTiles)
        {
            Tile.GetComponent<Renderer>().material.color = Color.white; //reset their color
            Tile.Reset(); //reset them, so they are not selectable 
        }

        selectableTiles.Clear(); //clear 
    }

    //calculate the heading
    void CalculateHeading(Vector3 Target)
    {
        heading = Target - transform.position; //heading is target minus the position
        heading.Normalize(); //normalize

    }

    //set their horizontal speed
    void SetHorizontalVelocity()
    {
        velocity = heading * moveSpeed; //heading and their move speed determine horizontal speed
    }

    //if they are jumping
    void Jumping(Vector3 target)
    {
        if(fallingDown)
        {
            fallDownward(target);
        }
        else if(jumpingUp)
        {
            jumpUpward(target);
        }
        else if(movingEdge)
        {
            MoveToEdge();
        }
        else
        {
            PrepareJump(target);
        }
    }

    void PrepareJump(Vector3 Target)
    {
        float targetY = Target.y;

        Target.y = transform.position.y;

        CalculateHeading(Target);
        if(transform.position.y > targetY)
        {
            fallingDown = false;
            jumpingUp = false;
            movingEdge = true;

            jumpTarget = transform.position + (Target - transform.position) / 2.0f;
        }
        else
        {
            fallingDown = false;
            jumpingUp = true;
            movingEdge = false;

            velocity = heading * moveSpeed / 3.0f;

            float difference = targetY - transform.position.y;

            velocity.y = jumpVelocity * (0.5f + difference / 2.0f);
        }
    }

    void fallDownward(Vector3 target)
    {
        velocity += Physics.gravity * Time.deltaTime;

        if(transform.position.y <= target.y)
        {
            fallingDown = false;
            jumpingUp = false;
            movingEdge = false;

            Vector3 vec = transform.position;

            vec.y = target.y;
            transform.position = vec;
            velocity = new Vector3();
        }
    }
    void jumpUpward(Vector3 target)
    {
        velocity += Physics.gravity * Time.deltaTime;

        if(transform.position.y > target.y)
        {
            jumpingUp = false;
            fallingDown = true;
        }
    }
    void MoveToEdge()
    {
        if(Vector3.Distance(transform.position, jumpTarget) >= 0.05f)
        {
            SetHorizontalVelocity();
        }
        else
        {
            movingEdge = false;
            fallingDown = true;

            velocity /= 5.0f;
            velocity.y = 1.5f;
        }
    }


    protected TileScript FindLowestF(List<TileScript> list)
    {
        TileScript lowest = list[0];

        foreach(TileScript t in list)
        {
            if(t.f < lowest.f)
            {
                lowest = t;
            }
        }

        list.Remove(lowest);

        return lowest;
    }
    protected TileScript FindEndTile(TileScript target)
    {
        Stack<TileScript> tempPath = new Stack<TileScript>();

        TileScript next = target.parent;
        while(next != null)
        {
            tempPath.Push(next);
            next = next.parent;
        }

        if(tempPath.Count <= move)
        {
            return target.parent;
        }

        TileScript endTile = null;
        for(int i=0; i <= move; i++)
        {
            endTile = tempPath.Pop();
        }

        return endTile;
    }

    protected void FindPath(TileScript target)
    {
        ComputedAdjencyLists(jumpHeight, target);
        GetCurrentTile();

        List<TileScript> openList = new List<TileScript>();
        List<TileScript> closeList = new List<TileScript>();

        openList.Add(currentTile);
        //currentTile.Parent = ???

        currentTile.h = Vector3.Distance(currentTile.transform.position, target.transform.position);
        currentTile.f = currentTile.h;

        while(openList.Count > 0)
        {
            TileScript t = FindLowestF(openList);

            closeList.Add(t);

            if(t == target)
            {
                actualTargetTile = FindEndTile(t);
                MoveToTile(actualTargetTile);
                return;
            }

            foreach(TileScript tile in t.adjacencyList)
            {
                if(closeList.Contains(tile))
                {
                    //do no ting
                }
                else if (openList.Contains(tile))
                {
                    float tempG = t.g + Vector3.Distance(tile.transform.position, t.transform.position);
                    
                    if(tempG < tile.g)
                    {
                        tile.parent = t;
                        tile.g = tempG;
                        tile.f = tile.g + tile.h;
                    }
                }
                else
                {
                    tile.parent = t;

                    tile.g = t.g + Vector3.Distance(tile.transform.position, t.transform.position);
                    tile.h = Vector3.Distance(tile.transform.position, target.transform.position);
                    tile.f = tile.g + tile.h;

                    openList.Add(tile);
                }
            }

        }
        //TODO what do if no path to target tile
        Debug.Log("Path no found");
    }

    public void BeginTurn()
    {
        turn = true;
    }

    public void EndTurn()
    {
        turn = false;
    }
}
