﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class BattleSystem : MonoBehaviour
{

   

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    //function for attacking enemies. Takes in the entitiy that will be trageted by the attack and the damage that will be attacked
    public void Attack(TacticsMove target, float damage)
    {
        float mod = UnityEngine.Random.Range(0.8f, 1.25f); //gets a randm float to modify the attack damage
        float totalDamage = damage * mod; //the total damage of the attack
        target.SetHealth(target.GetHealth() - totalDamage); //change the health of the target
        Debug.Log(target.GetHealth() + target.gameObject.tag);
    }
}
