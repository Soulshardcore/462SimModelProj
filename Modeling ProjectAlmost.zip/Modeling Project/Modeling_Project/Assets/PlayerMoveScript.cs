﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Will be used to process the player character moving

public class PlayerMoveScript : TacticsMove
{
    int range = 5;
    bool oneAttack = false;

    // Start is called before the first frame update
    void Start()
    {
        Init();
        health = 200f;
        damage = 15f;
        
        //range = 4;
    }

    // Update is called once per frame
    void Update()
    {
        
        oneAttack = false;
        Debug.DrawRay(transform.position, transform.forward);
        //when we update we find the selectable tiles
        //if we are not moving, find the selectable tiles

        if(!turn)
        {
            return;
        }
        if (!moving)
        {
            FindSelectableTiles();
            CheckMouse();
            //find a tile that has  aboi 
            //if ther is boi call attack function
            
        }
        else
        {
            Move();
        }
    }

    //check if the click on a selectable tile
    void CheckMouse()
    {
        if (Input.GetMouseButtonUp(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition); //creates a ray from where the mouse was clicked

            RaycastHit hit;
            if (Physics.Raycast(ray, out hit))
            {
                //if they clicked on a tile
                if (hit.collider.tag == "Tile")
                {
                    TileScript t = hit.collider.GetComponent<TileScript>();
                    if (t.selectable)
                    {
                        MoveToTile(t);
                    }
                }
                else if(hit.collider.tag == "NPC" && !oneAttack)
                {
                    NPCMove dingledong = hit.collider.gameObject.GetComponent<NPCMove>();
                    oneAttack = StartAttack(dingledong);
                    if(oneAttack)
                    {
                        TurnManager.EndTurn();
                    }
                }
            }
        }
    }

    //start the attack of the player
    public override bool StartAttack(TacticsMove rayonnaise)
    {
            //Debug.Log("dik1");
            foreach (TileScript t in selectableTiles)
            {
            //Physics.Raycast(tile.transform.position, Vector3.up, out hit, 1)
                RaycastHit rustard;
                //look for the target of the attack
                if(Physics.Raycast(rayonnaise.transform.position, -Vector3.up, out rustard, 1))
                {
                //if the target of the player is within the range
                    if(rustard.collider.gameObject.tag == "Tile" && rustard.collider.gameObject.GetComponent<TileScript>().distance <= range)
                    {
                        BS.Attack(rayonnaise, damage); //call the attack function
                        return true;
                    }
                }
                    
            }

            return false;
        
    }
    
    
    ////get health
    //public float GetHealth()
    //{
    //    return health;
    //}

    ////set health
    //public void SetHealth(float pHealth)
    //{
    //    health = pHealth;
    //}
}

