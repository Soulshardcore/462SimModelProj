﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPCMove : TacticsMove
{
    int range = 1;

    GameObject target;

    bool hitabitch = false;

   

    // Start is called before the first frame update
    void Start()
    {
        Init();
        health = 100f; //sets the health
        damage = 5f;
        move = 4;
    }

    // Update is called once per frame
    void Update()
    {
        Debug.DrawRay(transform.position, transform.forward);
        //when we update we find the selectable tiles
        //if we are not moving, find the selectable tiles

        if (!turn)
        {
            hitabitch = false;
            return;
        }

        if (!moving)
        {
            FindNearestTarget();
            CalculatePath();
            FindSelectableTiles();
            actualTargetTile.target = true;

        }
        else
        {
            if (!hitabitch)
            {
                StartAttack(target.GetComponent<PlayerMoveScript>());
            }
            Move();
        }
    }

    void CalculatePath()
    {
        TileScript targetTile = GetTargetTile(target);
        FindPath(targetTile);
    }

    void FindNearestTarget()
    {
        GameObject[] targets = GameObject.FindGameObjectsWithTag("Player");

        GameObject nearest = null;
        float distance = Mathf.Infinity;

        foreach(GameObject obj in targets)
        {          
            float d = Vector3.Distance(transform.position, obj.transform.position);
            
            if (d < distance)
            {
                distance = d;
                nearest = obj;
            }
        }


        target = nearest;
    }
    
    public override bool StartAttack(TacticsMove rayonnaise)
    {
        if(checkForPlayer(Vector3.forward))
        {
            BS.Attack(rayonnaise, damage);
            hitabitch = true;
            return true;
        }
        else if (checkForPlayer(-Vector3.forward))
        {
            BS.Attack(rayonnaise, damage);
            hitabitch = true;
            return true;
        }
        else if (checkForPlayer(-Vector3.right))
        {
            BS.Attack(rayonnaise, damage);
            hitabitch = true;
            return true;
        }
        else if (checkForPlayer(Vector3.right))
        {
            BS.Attack(rayonnaise, damage);
            hitabitch = true;
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public bool checkForPlayer(Vector3 check)
    {
        RaycastHit playerCast;

        Physics.Raycast(target.transform.position, -Vector3.up, out playerCast, 1);
        TileScript playerTile = playerCast.collider.gameObject.GetComponent<TileScript>();



        RaycastHit nearbyTiles;

        Physics.Raycast(actualTargetTile.transform.position, check, out nearbyTiles, 1);
        TileScript nearTile = nearbyTiles.collider.gameObject.GetComponent<TileScript>();

        if(playerTile == nearTile)
        {
            //Debug.Log("We got em boys");
            return true;
        }

        return false;
    }
}
