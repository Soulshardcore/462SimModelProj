﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public static class MenuScript
{
    [MenuItem("Tools/Assign Tile Material")] //will be used to access the correct tool to assign the tile material

    //will be used to assign the tile material
    public static void AssignTileMaterial()
    {
        GameObject[] tiles = GameObject.FindGameObjectsWithTag("Tile"); //looks for all the game objects with the tile tag
        Material material = Resources.Load<Material>("Tile"); //loads the needed material\

        //loops through all the tiles and will assign their material
        foreach (GameObject t in tiles)
        {
            t.GetComponent<Renderer>().material = material; //assigns their material
            
        }
    }

    [MenuItem("Tools/Assign Tile Script")]

    //will be used to assign the tile script
    public static void AssignTileScript()
    {
        GameObject[] tiles = GameObject.FindGameObjectsWithTag("Tile"); //looks for all the game objects with the tile tag
        

        //loops through all the tiles and will assign their script
        foreach (GameObject t in tiles)
        {
            t.AddComponent<TileScript>(); //adds the tile script to each tile
        }
    }

}
