﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Tactis Move will be used for all of the movement of both the player and enemy objects. 
//Contains all the movement algorithms as it is shared by players and NPCs
public class TacticsMove : MonoBehaviour
{
    public int move = 5; //how far the player can move. Defauls to 5
    public float jumpHeight = 2; //how far the player can jump, defaults to 2
    public float moveSpeed = 2; //how fast the unit will walk across the tiles

    public bool moving = false; //only look when its not moving

    Vector3 velocity = new Vector3(); //the velocity
    Vector3 heading = new Vector3(); //the direction the player is heading in
    List<TileScript> selectableTiles = new List<TileScript>(); //a list of the tiles the player can access, so we can change their color as needed
    GameObject[] tiles; //list of tiles as game objects

    Stack<TileScript> path = new Stack<TileScript>(); //allows us to backtrack to the starting tile
    TileScript currentTile; //the tile the player is on

    float halfHeight = 0; //how tall half the tile is


    //init function
    protected void Init()
    {
        tiles = GameObject.FindGameObjectsWithTag("Tile"); //gets all the tiles on the board
        halfHeight = GetComponent<Collider>().bounds.extents.y; //to calculate where to put the unit on the tile
    }

    //allows us to get current tile
    public void GetCurrentTile()
    {
        currentTile = GetTargetTile(gameObject); //gets the tile the player is currently sitting on
        currentTile.current = true; //assigns this tile the needed color of the current tile
    }

    //to get the target tile that we want to go to
    public TileScript GetTargetTile(GameObject target)
    {
        //needs to find the tile we are looking for

        RaycastHit hit;
        TileScript tile = null; //the tile we are looking for

        //checks to make sure there is a tile there
        //Debug.Log(Physics.Raycast(target.transform.position, -Vector3.up, out hit, 1) + " is response for should be player tile");
        if (Physics.Raycast(target.transform.position, -Vector3.up, out hit, 1))
        {
            tile = hit.collider.GetComponent<TileScript>(); //gets the tile that was there if there is one
        }

        return tile; //returns the tile we desire
    }

    //to get the tiles that are adjecent
    public void ComputedAdjencyLists()
    {
        //goes through all the tiles
        foreach(GameObject tile in tiles)
        {
            TileScript t = tile.GetComponent<TileScript>(); //gets the current tile in the list
            t.FindNeighbors(jumpHeight); //finds the neighbor tiles
        }
    }
    
    //will be used to do the BFS and find the tiles it can do
    public void FindSelectableTiles()
    {
        ComputedAdjencyLists(); //get the adject tiles
        GetCurrentTile(); //get the current tile

        Queue<TileScript> process = new Queue<TileScript>(); //makes a queue of the needed tiles

        process.Enqueue(currentTile); //will put the current tile in the queue
        currentTile.visited = true; //we dont want to come back to this tile after we visit it 
        //currentTile.parent = ?? //leave as null beacuse we dont want to include current tile in the path

        //as long as the queue is not empty
        while(process.Count > 0)
        {
            
            //prcess the tile at the head of the queue
            TileScript t = process.Dequeue(); //removes the first tile from the queue

            selectableTiles.Add(t); //adds the tile to the selectable list 
            t.selectable = true; //makes its color change to reflect you can pick it

            //need to check the distance if bigger than the move, we cant do
            if (t.distance < move)
            {
                //need to add all its neighbors to the queue
                foreach (TileScript tile in t.adjacencyList)
                {
                    //need to make sure we dont process the same tiles twice
                    if (!tile.visited)
                    {
                        tile.parent = t; //if the tile is visited make the current tile its parent
                                         //will set that for those adjectent to the tile
                        tile.visited = true; //we visited it
                        tile.distance = 1 + t.distance; //increases the distance
                        process.Enqueue(tile); //add it to the queue
                        Debug.Log("Tile added to queue: " + tile.gameObject.ToString());
                    }
                    else
                    {
                        Debug.Log("Tried to access a visited tile");
                    }
                }
            }
        }
    }
}
