﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Will be used to process the player character moving

public class PlayerMoveScript : TacticsMove
{
    // Start is called before the first frame update
    void Start()
    {
        Init();
    }

    // Update is called once per frame
    void Update()
    {
        Debug.DrawRay(transform.position, transform.forward);
        //when we update we find the selectable tiles
        //if we are not moving, find the selectable tiles
        if (!moving)
        {
            FindSelectableTiles();
            CheckMouse();
        }
        else
        {
            Move();
        }
    }

    //check if the click on a selectable tile
    void CheckMouse()
    {
        if (Input.GetMouseButtonUp(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition); //creates a ray from where the mouse was clicked

            RaycastHit hit;
            if (Physics.Raycast(ray, out hit))
            {
                //if they clicked on a tile
                if (hit.collider.tag == "Tile")
                {
                    TileScript t = hit.collider.GetComponent<TileScript>();
                    if (t.selectable)
                    {
                        MoveToTile(t);
                    }
                }
            }
        }
    }
    }

