﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

//Tactis Move will be used for all of the movement of both the player and enemy objects. 
//Contains all the movement algorithms as it is shared by players and NPCs
public abstract class TacticsMove : MonoBehaviour
{
    protected BattleSystem BS;// = new BattleSystem();

    protected float health; //health of the player
    protected float damage;

    protected bool hitEnemy; //checks if the player has hit the enemy to prevent the player form forever attacking
    public bool turn = false; //determines whose turn it is

    protected int move = 5; //how far the player can move. Defauls to 5
    public float jumpHeight = 2; //how far the player can jump, defaults to 2
    public float moveSpeed = 2; //how fast the unit will walk across the tiles

    public bool moving = false; //only look when its not moving

    bool fallingDown = false; //if they are falling
    bool jumpingUp = false; //if they are jumping
    bool movingEdge = false; //prepare for the jump, move to the edge to jump
    Vector3 jumpTarget; //where they want to jump to
    public float jumpVelocity = 4.5f; //how fast they jump

    Vector3 velocity = new Vector3(); //the velocity
    Vector3 heading = new Vector3(); //the direction the player is heading in
    protected List<TileScript> selectableTiles = new List<TileScript>(); //a list of the tiles the player can access, so we can change their color as needed
    GameObject[] tiles; //list of tiles as game objects

    Stack<TileScript> path = new Stack<TileScript>(); //allows us to backtrack to the starting tile
    TileScript currentTile; //the tile the player is on

    float halfHeight = 0; //how tall half the tile is

    public TileScript actualTargetTile; //the actual target for use in the attack. the tile they want to attack on

    //init function
    protected void Init()
    {
        tiles = GameObject.FindGameObjectsWithTag("Tile"); //gets all the tiles on the board
        halfHeight = GetComponent<Collider>().bounds.extents.y; //to calculate where to put the unit on the tile
        TurnManager.AddUnit(this); //add unit to turn manager
        BS = new BattleSystem(); //make a new battlesystem
    }

    //allows us to get current tile
    public void GetCurrentTile()
    {
        currentTile = GetTargetTile(gameObject); //gets the tile the player is currently sitting on
        currentTile.current = true; //assigns this tile the needed color of the current tile
    }

    //to get the target tile that we want to go to
    public TileScript GetTargetTile(GameObject target)
    {
        //needs to find the tile we are looking for

        RaycastHit hit;
        TileScript tile = null; //the tile we are looking for

        //checks to make sure there is a tile there
        if (Physics.Raycast(target.transform.position, -Vector3.up, out hit, 1))
        {
            tile = hit.collider.GetComponent<TileScript>(); //gets the tile that was there if there is one
        }

        return tile; //returns the tile we desire
    }

    //to get the tiles that are adjecent
    public void ComputedAdjencyLists(float jumpHeight, TileScript target)
    {
        //goes through all the tiles
        foreach(GameObject tile in tiles)
        {
            TileScript t = tile.GetComponent<TileScript>(); //gets the current tile in the list
            t.FindNeighbors(jumpHeight, target); //finds the neighbor tiles
        }
    }
    
    //will be used to do the BFS and find the tiles it can do
    public void FindSelectableTiles()
    {
        ComputedAdjencyLists(jumpHeight, null); //get the adject tiles
        GetCurrentTile(); //get the current tile

        Queue<TileScript> process = new Queue<TileScript>(); //makes a queue of the needed tiles

        process.Enqueue(currentTile); //will put the current tile in the queue
        currentTile.visited = true; //we dont want to come back to this tile after we visit it 
        
        //as long as the queue is not empty
        while(process.Count > 0)
        {
            
            //prcess the tile at the head of the queue
            TileScript t = process.Dequeue(); //removes the first tile from the queue

            selectableTiles.Add(t); //adds the tile to the selectable list 
            RaycastHit hit;
            if(!Physics.Raycast(t.transform.position, Vector3.up, out hit, 1))
            {
                t.selectable = true; //makes its color change to reflect you can pick it
            }
           
            //Debug.Log("starting process");
            //need to check the distance if bigger than the move, we cant do
            if (t.distance < move)
            {
                //Debug.Log("It made it into t.distance < move");
                //need to add all its neighbors to the queue
                foreach (TileScript tile in t.adjacencyList)
                {
                    //Debug.Log("It made it into foreach");
                    //need to make sure we dont process the same tiles twice
                    if (!tile.visited)
                    {
                        tile.parent = t; //if the tile is visited make the current tile its parent
                                         //will set that for those adjectent to the tile
                        tile.visited = true; //we visited it
                        tile.distance = 1 + t.distance; //increases the distance
                        process.Enqueue(tile); //add it to the queue
                        //Debug.Log("Tile added to queue: " + tile.gameObject.ToString());
                    }
                }
            }
        }
    }

    //To allow the player to move to the tile they selected
    public void MoveToTile(TileScript tile)
    {
        path.Clear(); //clear any previous path
        tile.target = true; //becomes the target tile
        moving = true; //start moving

        //make it the next tile
        TileScript nextTile = tile;
        //while we are not at the tile with no parent
        while(nextTile != null)
        {
            path.Push(nextTile); //add to the path stack
            nextTile = nextTile.parent; //make the next tile the parent to move back in the path
        }
    }

    //moves the player to the tile
    public void Move()
    {
        //as long as there is a path
        if(path.Count > 0)
        {
            TileScript t = path.Peek(); //peek at the next tile in path
            Vector3 target = t.transform.position; //transform the current position
              
            //Move the player onto the square where they should be, and make sure they aren't halfway in the square or what have you
            target.y += halfHeight + t.GetComponent<Collider>().bounds.extents.y;

            //if the distance is bigger than .05
            if(Vector3.Distance(transform.position, target) >= 0.05f)
            {
                bool jump = transform.position.y != target.y; //if the player has to jump
               
                //if they have to jump
                if (jump)
                {
                    Jumping(target);  //calls jump function and passes in the tile they want to jump to
                }
                //if they do not have to jump
                else
                {
                    CalculateHeading(target); //passes the target tile into the heading function
                    SetHorizontalVelocity(); //sets the horizontal velocity
                }

                transform.forward = heading; //after heading is calculated we set the direction we're going
                transform.position += velocity * Time.deltaTime; //moves the position
            }
            else
            {
                //tile reached
                transform.position = target; //the position is changed to the tile that was the target
                path.Pop(); //remove form stack
            }
        }
        else
        {
            RemoveSelectableTiles(); //remove the tiles that were selectable 
            moving = false; //end the moving
            TurnManager.EndTurn(); //end the turn
        }
    }

    //to remove the tiles that were selectable
    protected void RemoveSelectableTiles()
    {
        //as long as there is a current tile
        if(currentTile != null)
        {
            currentTile.current = false; //make it not the current tile
            currentTile = null; //make no current tile
        }

        //for all of the perviously selectable tiles
        foreach(TileScript Tile in selectableTiles)
        {
            Tile.GetComponent<Renderer>().material.color = Color.white; //reset their color
            Tile.Reset(); //reset them, so they are not selectable 
        }

        selectableTiles.Clear(); //clear 
    }

    //calculate the heading
    void CalculateHeading(Vector3 Target)
    {
        heading = Target - transform.position; //heading is target minus the position
        heading.Normalize(); //normalize distance to target

    }

    //set their horizontal speed
    void SetHorizontalVelocity()
    {
        velocity = heading * moveSpeed; //heading and their move speed determine horizontal speed
    }

    //if they are jumping
    void Jumping(Vector3 target)
    {
        //Debug.Log(fallingDown);
        if(fallingDown)
        {
            fallDownward(target); //if falling is true the tile is below and they are going down
        }
        else if(jumpingUp)
        {
            jumpUpward(target); //if jumping up is true the tile is above and they are moving up
        }
        else if(movingEdge)
        {
            MoveToEdge(); //if moving edge is true the player has to move to the edge of a tile prior to jumping
        }
        else
        {
            PrepareJump(target); //otherwise they get ready to jump
        }
    }

    //so they can get ready to jump
    void PrepareJump(Vector3 Target)
    {
        float targetY = Target.y; //the y position of the tile we want to reach

        Target.y = transform.position.y; //sets the target location of the tile we are trying to reach by movement

        CalculateHeading(Target); //Normalize values towards target destination
        if(transform.position.y > targetY)//if the location we want to get to is larger than the target
        {
            //ensure we're not jumping or falling
            fallingDown = false;
            jumpingUp = false;
            movingEdge = true; //We're moving to the edge

            jumpTarget = transform.position + (Target - transform.position) / 2.0f; //The transform associated with the jump
        }
        else
        {
            //we're starting to jump up, so that's true, and ensure that we're not moving to the edge or falling
            fallingDown = false;
            jumpingUp = true;
            movingEdge = false;

            velocity = heading * moveSpeed / 3.0f; //the speed at which we're jumping

            float difference = targetY - transform.position.y; // add a little difference to make sure we make the jump

            velocity.y = jumpVelocity * (0.5f + difference / 1.3f); //finish applying the jumping velocity
        }
    }

    void fallDownward(Vector3 target)
    {
        velocity += Physics.gravity * Time.deltaTime; //fall in relation to earth's gravity

        if(transform.position.y <= target.y) //we've made to the tile that we were falling to
        {
            fallingDown = false;
            jumpingUp = false;
            movingEdge = false;

            Vector3 vec = transform.position;

            vec.y = target.y;
            transform.position = vec;
            velocity = new Vector3();
        }
    }
    void jumpUpward(Vector3 target)
    {
        velocity += Physics.gravity * Time.deltaTime; //jump but also consider gravity

        //if we're higher than our target, we're about to start falling
        if(transform.position.y > target.y)
        {
            jumpingUp = false;
            fallingDown = true;
        }
    }
    void MoveToEdge()
    {       
        if(Vector3.Distance(transform.position, jumpTarget) >= 0.12f) //if we're close to our target tile that is of different height
        {
            SetHorizontalVelocity(); //set the speed we are
        }
        else
        {
            //We're going to be falling, so we're not moving to the edge anymore
            movingEdge = false;
            fallingDown = true;

            //change the velocity; changes jump height and effectively distance    
            velocity /= 5.0f;
            velocity.y = 1.5f;
        }
    }


    protected TileScript FindLowestF(List<TileScript> list)
    {
        //Find the nearest tile that the npc can reach that still comes close to the player
        TileScript lowest = list[0];

        foreach(TileScript t in list)
        {
            //every tile in the list using A* find the quickest path to the Player
            if(t.f < lowest.f)
            {
                lowest = t;
            }
        }

        list.Remove(lowest);

        return lowest;
    }
    protected TileScript FindEndTile(TileScript target)
    {
        //Calculate the path to the end tile that is closest to the player considering range of movement
        Stack<TileScript> tempPath = new Stack<TileScript>();

        TileScript next = target.parent;
        while(next != null)
        {
            tempPath.Push(next);
            next = next.parent;
        }

        if(tempPath.Count <= move)//if the path is less than or equal to our npc move distance
        {
            return target.parent;
        }

        TileScript endTile = null;
        for(int i=0; i <= move; i++)//return the final tile that we want to go to
        {
            endTile = tempPath.Pop();
        }

        return endTile;
    }

    protected void FindPath(TileScript target)
    {
        //using the target that was found, get as close to the player as possible
        ComputedAdjencyLists(jumpHeight, target);
        GetCurrentTile();

        List<TileScript> openList = new List<TileScript>();
        List<TileScript> closeList = new List<TileScript>();

        openList.Add(currentTile);
        //currentTile.Parent = ???

        currentTile.h = Vector3.Distance(currentTile.transform.position, target.transform.position);
        currentTile.f = currentTile.h;

        while(openList.Count > 0)
        {
            //find shortest tilepath
            TileScript t = FindLowestF(openList);

            closeList.Add(t);

            if(t == target)
            {
                //move to the tile that we found was closest to the player
                actualTargetTile = FindEndTile(t);
                MoveToTile(actualTargetTile);
                return;
            }

            foreach(TileScript tile in t.adjacencyList)
            {
                if(closeList.Contains(tile))
                {
                    //do nothing
                }
                else if (openList.Contains(tile))
                {
                    //keep trying to use A* to figure out the next best tile to move to using A*
                    float tempG = t.g + Vector3.Distance(tile.transform.position, t.transform.position);
                    
                    if(tempG < tile.g)
                    {
                        tile.parent = t;
                        tile.g = tempG;
                        tile.f = tile.g + tile.h;
                    }
                }
                else
                {
                    //Start the process of finding the next tile to move to
                    tile.parent = t;

                    tile.g = t.g + Vector3.Distance(tile.transform.position, t.transform.position);
                    tile.h = Vector3.Distance(tile.transform.position, target.transform.position);
                    tile.f = tile.g + tile.h;

                    openList.Add(tile);
                }
            }

        }
        //TODO what do if no path to target tile
        Debug.Log("Path no found");
    }

    public void BeginTurn()
    {
        turn = true;
    }

    public void EndTurn()
    {
        turn = false;
    }

    //get health
    public float GetHealth()
    {
        return health;
    }

    //set health
    public void SetHealth(float pHealth)
    {
        health = pHealth;
    }

    //start npc or player attack
    public abstract bool StartAttack(TacticsMove rayonnaise);

    //public abstract void CheckMouseEnemy();
    //Fragment of a forgotten time; doesn't do jack shit



}
