﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

//Will be used to process the player character moving

public class PlayerMoveScript : TacticsMove
{
    int range = 5; //the range of the player attacks
    //bool oneAttack = false;

    // Start is called before the first frame update
    void Start()
    {
        Init(); //initilizes the player
        health = 20f; //sets the health 
        damage = 15f; //sets the damage they can do
        hitEnemy = false; //makes it so they havent hit the enemy yet

    }

    // Update is called once per frame
    void Update()
    {
        Debug.DrawRay(transform.position, transform.forward); //the direction the player is facing
       
        //check if the player still has health
        if (health <= 0.0f)
        {
            RemoveSelectableTiles(); //remove all tiles that could be selected
            Destroy(this.gameObject); //destroy the player object
            Debug.Log("YOU LOST"); //display you lost text
        }
        //if it is not their turn
        if (!turn)
        {
            hitEnemy = false; //reset weather or not they hit the enemy 
            return;
        }
        //when we update we find the selectable tiles
        //if we are not moving, find the selectable tiles
        if (!moving)
        {
            FindSelectableTiles();
            CheckMouse();
            //find a tile that has  aboi 
            //if ther is boi call attack function
            
        }
        else
        {
            Move(); //move the player
        }
    }

    //check if they click on a selectable tile
    public void CheckMouse()
    {
        if (Input.GetMouseButtonUp(0))
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition); //creates a ray from where the mouse was clicked

            RaycastHit hit;
            if (Physics.Raycast(ray, out hit))
            {
                //if they clicked on a tile
                if (hit.collider.tag == "Tile")
                {
                    TileScript t = hit.collider.GetComponent<TileScript>();
                    //check if the tile is selectable 
                    if (t.selectable)
                    {
                        MoveToTile(t); //move to the tile they wanted 
                    }
                }
                //if they clicked on an enemy and have not already hit the enemy
                else if(hit.collider.tag == "NPC" && !hitEnemy)
                {
                    NPCMove dingledong = hit.collider.gameObject.GetComponent<NPCMove>(); //get the object that the player wants to attack
                    //if they have not already hit the enemy once
                    if(!hitEnemy)
                    {
                        StartAttack(dingledong); //start attacking the enemy
                    }
                }
            }
        }
    }



    //start the attack of the player
    public override bool StartAttack(TacticsMove rayonnaise)
    {
        //go through all the tiles in the selectable tiles
        foreach (TileScript t in selectableTiles)
        {
            RaycastHit rustard; //raycast
            //look for the target of the attack
            if (Physics.Raycast(rayonnaise.transform.position, -Vector3.up, out rustard, 1))
            {
                //if the target of the player is within the range
                if (rustard.collider.gameObject.tag == "Tile" && rustard.collider.gameObject.GetComponent<TileScript>().distance <= range && rustard.collider.gameObject.GetComponent<TileScript>().distance > 0)
                {
                    BS.Attack(rayonnaise, damage); //call the attack function
                    hitEnemy = true; //make sure to keep track of if they hit the enemy this turn
                    return true; //was a success
                }
            }

        }
        return false; //was a failure. they did not his the enemy
    }

    //left over from the idea that the player might be able to choose the order they attack and move.
    //sadly this turned out to be a much bigger issue than we first anticipated
    //public override void CheckMouseEnemy()
    //{
    //    if (Input.GetMouseButtonUp(0))
    //    {
    //        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition); //creates a ray from where the mouse was clicked

    //        RaycastHit hit;
    //        if (Physics.Raycast(ray, out hit))
    //        {
    //            if (hit.collider.tag == "NPC" && !hitEnemy)
    //            {
    //                NPCMove dingledong = hit.collider.gameObject.GetComponent<NPCMove>();
    //                //oneAttack = StartAttack(dingledong);
    //                if (!hitEnemy)
    //                {
    //                    StartAttack(dingledong);
    //                }
    //            }
    //        }
    //    }
    //    Debug.Log("Whats the problem");
    //}
}

