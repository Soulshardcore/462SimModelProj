﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TatcticCamera : MonoBehaviour
{
    //to rotate left
    public void RotateLeft()
    {
        //rotate the camera to the left 90 degrees around the y axis
        transform.Rotate(Vector3.up, 90, Space.Self);
    }

    //to rotate right
    public void RotateRight()
    {
        //rotate the camera to the right 90 degrees around the y axis
        transform.Rotate(Vector3.up, -90, Space.Self);
    }
    
}
