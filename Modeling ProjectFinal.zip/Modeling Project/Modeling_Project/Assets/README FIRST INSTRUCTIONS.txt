The two characters have 20 health
The player, the pink capsule, has a gun.
They can shoot from a range of 5 blocks away.
The enemy, the green capsule, has to be right 
next to the player on the same level to damage them 
because they have a knife.
Blue tiles denote spots that the current player can move to.
The player must attack before moving.
The damage taken and remaining health are noted in the console.
When the player takes too much damage or the NPC does, it gets
noted in console who won.



