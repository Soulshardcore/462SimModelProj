﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class NPCMove : TacticsMove
{
    int range = 1; //the range of the npc

    GameObject target; //the target tile it wants to move to

    bool hitabitch = false; //if they have hit the player this turn

   

    // Start is called before the first frame update
    void Start()
    {
        Init(); //initilizes the enemy
        health = 20f; //sets the health
        damage = 5f; //the damage the enemy can do
        move = 2; //changes how far it can move, to give the player a chance
    }

    // Update is called once per frame
    void Update()
    {
        Debug.DrawRay(transform.position, transform.forward); //the direction the npc is facing
        //checks if the npc still has health
        if(health <= 0.0f)
        {
            RemoveSelectableTiles(); //remove all the tiles that could be selected
            Destroy(this.gameObject); //destroy the enemy object
            Debug.Log("YOU WON"); //display you won text
            
        }
        //if its not their turn
        if (!turn)
        {
            hitabitch = false; //make it so it hasnt hit the player yet
            return;
        }
        //when we update we find the selectable tiles
        //if we are not moving, find the selectable tiles
        if (!moving)
        {
            FindNearestTarget(); //find the nearest target it wants to hit
            CalculatePath(); //calculate the path to the target
            FindSelectableTiles(); //find the tiles it can select for show
            actualTargetTile.target = true; //the actual target is the target 

        }
        else
        {
        //if it has not hit the player
            if (!hitabitch)
            {
                StartAttack(target.GetComponent<PlayerMoveScript>()); //hits the player with an attack
            }
            Move(); //moves
        }
    }

    //calculates the path it wants to take
    void CalculatePath()
    {
        TileScript targetTile = GetTargetTile(target); //get the target tile
        FindPath(targetTile); //pass the target tile into the find the path function
    } 

    //find the closest player to it
    void FindNearestTarget()
    {
        GameObject[] targets = GameObject.FindGameObjectsWithTag("Player"); //make a lit of all the objects with the player tag

        GameObject nearest = null; //set the nearest to null
        float distance = Mathf.Infinity; //distance goes on forever so it will find all the players

        //for all the object in the targets list
        foreach(GameObject obj in targets)
        {          
            float d = Vector3.Distance(transform.position, obj.transform.position); //the distance to the target
            
            //if the new distance is shorter
            if (d < distance)
            {
                distance = d; //change the distance
                nearest = obj; //make that object the cloest 
            }
        }
        target = nearest; //target the nearest player
    }
    
    //to start attacking the player
    public override bool StartAttack(TacticsMove rayonnaise)
    {
        //look for the player in front of the npc
        if(checkForPlayer(Vector3.forward))
        {
            BS.Attack(rayonnaise, damage); //attack the player using the player object
            hitabitch = true; //set it so they have hit the player and cant again
            return true; //success
        }
        //look for the player behind the npc
        else if (checkForPlayer(-Vector3.forward))
        {
            BS.Attack(rayonnaise, damage); //attack the player using the player object
            hitabitch = true; //set it so they have hit the player and cant again
            return true; //success
        }
        //check for the player to the left of the npc
        else if (checkForPlayer(-Vector3.right))
        {
            BS.Attack(rayonnaise, damage); //attack the player using the player object
            hitabitch = true; //set it so they have hit the player and cant again
            return true; //success
        }
        //check for the player to the right of the npc
        else if (checkForPlayer(Vector3.right))
        {
            BS.Attack(rayonnaise, damage); //attack the player using the player object
            hitabitch = true; //set it so they have hit the player and cant again
            return true; //success
        }
        else
        {
            return false; //failure to hit
        }
    }
    
    //check for the player
    public bool checkForPlayer(Vector3 check)
    {
        RaycastHit playerCast; //raycast to find the player

        Physics.Raycast(target.transform.position, -Vector3.up, out playerCast, 1); //look for the player
        TileScript playerTile = playerCast.collider.gameObject.GetComponent<TileScript>(); //get the player tile



        RaycastHit nearbyTiles; //check for nearby tiles

         
        TileScript nearTile = null; //make the near tile

        //look for the player on the tiles that are near to the npc, ie right next to
        Physics.Raycast(actualTargetTile.transform.position, check, out nearbyTiles, 1);
       //if it collides
        if (nearbyTiles.collider != null)
        {
            nearTile = nearbyTiles.collider.gameObject.GetComponent<TileScript>(); //make the near tile the tile that was hit
        }

        //if the player is on the near tile
        if(playerTile == nearTile)
        {
            return true; //success
        }

        return false; //else the player is not next to the npc
    }
}
